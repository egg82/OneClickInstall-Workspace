# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Empty::Application.config.secret_token = '0c64bf93db915cd615abffa56b5e29dd520a5afc5d6960f5962e8c2f2d566dbc01bae2f1dc43656a4867bd6905e04838278ab2771aa6809e11676a8189edb016'
